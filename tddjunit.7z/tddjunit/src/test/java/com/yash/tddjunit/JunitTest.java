package com.yash.tddjunit;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.yash.servicImpl.Service;

public class JunitTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//System.out.println("@BeforClass");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		//System.out.println("@AfterClass");
	}

	@Before
	public void setUp() throws Exception {
		//System.out.println("@Befor");
	}

	@After
	public void tearDown() throws Exception {
		//System.out.println("@After");
	}

	@Test(expected = NullPointerException.class )
	public void testCalculator_FirstArgumentNull_shoudReturnNullPointerException() {
		Service service=new Service();
		Integer num1 = null;
		Integer num2=5;
		
		int result=service.add(num1,num2);
		assertEquals(NullPointerException.class, result);		
	}
	
	@Test(expected = NullPointerException.class)
	public void testCalculator_SecondArgumentNull_ShouldReturnNullPointerException() {
		Service service  = new Service();
		Integer num1=6;
		Integer num2=null;
		
		int result = service.add(num1, num2);
		assertEquals(NullPointerException.class, result);
	}
	
	@Test
	public void Caculate_AdditionOfTwoNumber_FirstNumberIsZero_ShouldReturnSecondNumber() {
		Service servic = new Service();
		int num1=0;
		int num2=9;		
		int result = servic.add(num1, num2);
		System.out.println("Sum : "+result);
		assertEquals(num2, result);
	}
	
	@Test
	public void Calculate_AdditionOfTwoNumber_SecondNumberIsZero_ShoulReturnFirstNUmber(){
		Service service = new Service();
		int num1=4;
		int num2=0;
		int result = service.add(num1, num2);
		System.out.println("Sum : "+result);
		assertEquals(num1, result);
	}

}
