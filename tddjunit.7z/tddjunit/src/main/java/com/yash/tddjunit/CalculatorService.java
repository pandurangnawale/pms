package com.yash.tddjunit;

public interface CalculatorService {
	
	int add(int a,int b);
	
}
