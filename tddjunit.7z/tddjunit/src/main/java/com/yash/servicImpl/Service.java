package com.yash.servicImpl;

import com.yash.tddjunit.CalculatorService;

public class Service implements CalculatorService{
	
	public int add(int num1,int num2) {
		if(num1 < 1){
			return num2;
		}
		return num1+num2;
	}

}
