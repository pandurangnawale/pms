package com.yash.junit_mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import service.CalculateInterface;
import serviceimpl.HelperClass;

public class AddTwoNumberTestCase {
	
	HelperClass helpOb;
	CalculateInterface calculateInterface= mock(CalculateInterface.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {		 
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		helpOb = new HelperClass();
		when(calculateInterface.add(5, 2)).thenReturn(7);
		
		//when(calculateInterface.sub(5, 2)).thenReturn(3);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddOfTwoNo() {
		
		Integer a = 5;
		Integer b = 2;		
		assertEquals(7, calculateInterface.add(a, b));	
		
		when(calculateInterface.sub(5, 2)).thenReturn(3);
	}

}
