package serviceimpl;

import service.CalculateInterface;

public abstract class CalculateImpl implements CalculateInterface{

	public int add(int a, int b) {		
		return a+b;
	}
	
	

}
