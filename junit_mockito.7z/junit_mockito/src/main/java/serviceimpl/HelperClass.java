package serviceimpl;

import service.CalculateInterface;

public class HelperClass {
	
	CalculateInterface calculateInterface;
	
	public HelperClass(){
		this.calculateInterface=calculateInterface;
	}
	
	public int add(int a,int b){
		return calculateInterface.add(a, b);
	}
	
	

}
