package controller;

import service.CalculateInterface;

public class CalculateController {
	CalculateInterface calculateInterface;
	int a=5;
	int b=2;
	int result=calculateInterface.add(a, b);
	
}
