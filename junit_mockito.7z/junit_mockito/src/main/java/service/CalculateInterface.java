package service;

public interface CalculateInterface {
	int add(int a,int b);
	
	int sub(int a,int b);
}
