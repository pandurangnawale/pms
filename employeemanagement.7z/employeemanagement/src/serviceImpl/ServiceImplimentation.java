package serviceImpl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import model.Employee;
import service.EmployeeInterface;

public class ServiceImplimentation implements EmployeeInterface{
	
	List<Employee> empAl = EmployeeInterface.empList();
	
	public List<Employee> getEmpById(int empId){
		
		Predicate<Employee> getEmpById = (empIdList)->empIdList.getEmpId() ==empId;
		
		
		List<Employee> resultList = new ArrayList<Employee>(); 
		resultList = (List<Employee>) empAl.stream()
					.filter(getEmpById)
					.collect(Collectors.toList());
		return resultList;
	}

	@Override
	public List<Employee> getEmpByName(String empName) {
		
		Predicate<Employee> getEmpByName = (empNameList)->empNameList.getEmpName().equalsIgnoreCase(empName);
		
		List<Employee> empList = new ArrayList<>();
		empList = empAl.stream()
					.filter(getEmpByName)
					.collect(Collectors.toList());		
		return empList;
	}

	@Override
	public List<Employee> getHighSalaryEmp() {
		List<Employee> empList = new ArrayList<>();
			System.out.println(empAl.stream().sorted(Comparator.comparingInt(Employee::getSalary)).findFirst().get());
		return empList;
	}
	
	
}
