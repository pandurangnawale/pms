package utility;

import java.util.List;
import java.util.Scanner;

import model.Employee;
import service.EmployeeInterface;
import serviceImpl.ServiceImplimentation;

public class mainClass {

	public static void main(String[] args) {		
		
		System.out.println("Enter 1 for Get Employee By Id");
		System.out.println("Enter 2 for Get Employee By Dept");
		System.out.println("Enter 3 for Get Highest Salary Emp");
		System.out.println("Enter 4 for Get Employee By Name");
		System.out.println("Enter 5 for Get Employee By Name & Salary");
		System.out.println("Enter 6 for Get Department List");
		System.out.println("Enter 0 for Exit ");
		
		Scanner sc = new Scanner(System.in);		
		int userchoice=sc.nextInt();
		EmployeeInterface service=new ServiceImplimentation();
		boolean x = true;
		try{
			do{
			switch(userchoice){
				case 1:{
					//ServiceImplimentation service = new ServiceImplimentation();
					
					System.out.println("Enter Employee Id to Search : ");
					int empId=sc.nextInt();
					List<Employee> al= service.getEmpById(empId);
					System.out.println("Employee List : "+al);
					break;
				}
				case 2:{
					System.out.println("Enter Employee Name to Search : ");
					String empName=sc.nextLine(); 
					List<Employee> al = service.getEmpByName(empName);
					System.out.println("Employee List : "+al);
					break;
				}
				case 3:{
					System.out.println("Please wait...");
					service.getHighSalaryEmp();
					//getHighSalaryEmp
					break;
				}
				case 4:{
					System.out.println("Please wait...");
					break;
				}
				case 5:{
					System.out.println("Please wait...");
					break;
				}
				case 6:{
					System.out.println("Please wait...");
					break;
					
				}
				case 0:{
					x=false;
					System.out.println("Thank You");
					System.exit(0);
					
					break;
				}
			
			} //switch
		} //do
		      while(x == true);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		

	}

}
