package com.yash.ems;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import model.Employee;
import service.EmployeeInterface;

public class EmsTestCases {

	EmployeeInterface employeeInterface= mock(EmployeeInterface.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSearchEmpbyId_IdShoulBeNumber_ShouldReturnMatchEmpList() {
		List<Employee> al = new ArrayList<Employee>();
		when(employeeInterface.getEmpById(101)).thenReturn(al);
	}

}
