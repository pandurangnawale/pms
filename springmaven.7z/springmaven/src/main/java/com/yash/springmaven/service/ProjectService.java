package com.yash.springmaven.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.springmaven.model.Project;
@Service
public class ProjectService {

	public List<Project> projects = new ArrayList<Project>();{
		projects.add(new Project("1", "ERP", "ERP SYSTEM"));
	}
			
			
			//Arrays.asList(new Project("1", "ERP", "ERP SYSTEM"),new Project("2", "EMS", "EMPLOYEE MANAGEMENT"),new Project("3", "JD", "JON DEER"));
	
	public List<Project> projectList(){
		return projects;
	}

	public List<Project> getProjectById(String id) {
		
		return   projects.stream().filter(pr->pr.getId().equals(id));
	}

	public void addProject(Project projectObj) {		
		projects.add(projectObj);
		System.out.println("UPDATED LIST "+projects);
	}
	
}
